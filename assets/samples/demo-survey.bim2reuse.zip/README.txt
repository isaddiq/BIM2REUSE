BIM2REUSE project package

project.json   project data (format bim2reuse-project, version 2)
models/        source IFC files, named by their SHA-256 hash
evidence/      passport evidence files, named by their SHA-256 hash
documents/     building survey documents, photographs and plan images, named by their SHA-256 hash

Open it in BIM2REUSE with Open project > Import package.
